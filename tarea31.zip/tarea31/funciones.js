// Función para crear un nodo con un valor y una lista de hijos
function createNode(value, children) {
    return {
      "value": value,
      "children": children || []
    };
  }
  
  // Crear la jerarquía de nodos
  var rootNode = createNode("A", [
    createNode("B", [
      createNode("D"),
      createNode("E")
    ]),
    createNode("C", [
      createNode("F"),
      createNode("G")
    ])
  ]);
  
  // Convertir el objeto a formato JSON
  var jsonString = JSON.stringify(rootNode, null, 2);
  
  console.log(jsonString);
  